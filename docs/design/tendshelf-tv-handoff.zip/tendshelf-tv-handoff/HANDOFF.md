# Tendshelf TV: handoff

**For:** the coding agent starting the Tendshelf TV project.
**What:** a living-room app for Tendshelf, in its own repo, that talks to the same Tendshelf server as the web app.

Ship **Apple TV** and **LG** first, together. The LG build is the web TV app, which later packages for Samsung and Android TV too.

It isn't the web app made bigger. It's read from across a room and driven with arrows and one button, so it has its own layouts, its own focus model and its own navigation. The brand (colours, type, voice) is the same.

Start with `screens/01-overview.png`, then the screens in order. Open `web-prototype/index.html` in a desktop browser and use the arrow keys to feel the focus model.

## 1. The project

```
tendshelf-tv/                 new repo
  apple/                      tvOS app: Swift + SwiftUI, tvOS 17+
  web/                        web TV app: TypeScript, no UI framework required, built to static files
    platforms/webos/          appinfo.json, icons; packaged with the webOS CLI (ares-package)
    platforms/tizen/          later: Samsung
    platforms/androidtv/      later: a thin wrapper around the same build
  shared/
    tokens.json               copied from design/tokens.json; generate Swift and CSS from it
    strings.en.json           every string in this doc's copy deck, one source for both apps
    api.md                    the contract in section 3
```

- **Why two code bases:** Apple TV apps can't show web content (tvOS has no web view), so Apple TV must be native. LG, Samsung and Android TV run web apps, so one web build covers them.
- **The main Tendshelf repo** gets the small JSON API in section 3. The TV apps never use the HTML/HTMX pages.

## 2. Screens (v1)

All at 1920 × 1080, always dark. On Apple TV, design points equal these pixels.

| # | Screen | What it does |
| --- | --- | --- |
| 01 | Overview | The rules: focus, remotes, safe area. A design page, not an app screen. |
| 02 | Sign in | Shows a six-character code and a QR code. You enter the code on your phone at `tendshelf.home/tv`, or scan it. No typing a password with the remote. |
| 03 | Who's listening? | One face per person on the server, plus "Add someone". Rosa's profile notes "Large text"; on TV that bumps body text from 30 to 36 px. |
| 04 | Home · focus on Resume | Full-screen backdrop from the current book's cover. A "Continue listening" hero with Resume, Read along and Chapters, and the "Up next on your shelf" row. |
| 05 | Home · focus in the row | The backdrop and hero follow the focused book once focus has rested 300 ms. Moving up returns to the hero's buttons. |
| 06 | Library | Filters as a pill row (All, In progress, Not started, Finished, Read along, Series, Authors) and a six-column grid of 248 px covers. A badge marks read-along books. |
| 07 | Book | Backdrop, series line, title, credits, format chips, two lines of summary, the buttons (Resume chapter 12, Read along, Bookmark, More), and a row of chapter tiles with the current one marked. |
| 08 | Search | Letter grid on the left (a–z, 0–9, Space, Delete, Clear), results on the right (Books, then Series and authors). The phone can type for the TV (section 3). |
| 09 | Now playing · controls | Big cover, title, chapter, "18:12 left in chapter", the book's progress with chapter ticks, then speed, back 15, play/pause, forward 30 and sleep. Remote hints sit top right. |
| 10 | Now playing · ambient | After 8 s without input the controls fade, leaving a calm cover, title, chapter and thin progress, with a clock. Any button brings the controls back. |
| 11 | Chapters panel | Slides in from the right over Now playing (▲ on LG, swipe up on Apple TV). Played chapters are checked, the current one says "Playing", and focus starts on the next chapter. |
| 12 | Sleep timer panel | End of chapter (with its time), 15, 30 or 60 minutes, Off. The voice fades out over the last 10 s. |
| 13 | Read along | One sentence at a time for the room: the current sentence at 60 px with the ember wash and word underline, the sentences before and after dimmed. ◀ ▶ move by sentence, OK pauses. |

Not in v1: downloads, admin, the Research lab, notes editing, the ebook-only reader (text without audio). TV shows bookmarks; it doesn't edit notes.

## 3. Server API (add to the main Tendshelf repo)

JSON over HTTPS on the user's server, with bearer tokens. All times are seconds into the book; all ids are strings.

**Device sign-in.** This follows the OAuth 2.0 device authorization grant (RFC 8628), which is what TV apps use.

| Call | Body or result |
| --- | --- |
| `POST /api/tv/device` | → `{ device_code, user_code: "K7Q4PM", verification_uri: "https://<server>/tv", verification_uri_complete: "https://<server>/tv?code=K7Q4PM", expires_in: 300, interval: 5 }`. The TV shows `user_code` as `K7Q·4PM` and a QR code of `verification_uri_complete`. |
| Phone page `GET /tv` | A web page in the main app (HTMX). The person is already signed in on their phone; they enter or confirm the code and choose which profiles this TV may use. |
| `POST /api/tv/token` `{ device_code }` | `428 { error: "authorization_pending" }` until approved, `410` when expired, then `200 { access_token, refresh_token, server_name: "Reyes family shelf", profiles: [{ id, name, initials, color, large_text }] }`. Poll every `interval` seconds. |
| `POST /api/tv/token/refresh` `{ refresh_token }` | → new tokens. The TV stays signed in until someone removes it under Users & invites on the web. |
| `POST /api/tv/profile` `{ profile_id }` | → a profile-scoped `access_token`. Everything below is for that person. |

**Listening.**

| Call | Result |
| --- | --- |
| `GET /api/home` | `{ continue: Book?, rows: [{ id, title: "Up next on your shelf", books: [BookCard] }] }` |
| `GET /api/books?filter=all\|in_progress\|not_started\|finished\|read_along&sort=added\|title\|author&cursor=` | `{ books: [BookCard], next_cursor }`, 60 per page |
| `GET /api/books/{id}` | `Book`: title, authors, narrators, series `{ name, position, count }`, summary, length, year, publisher, formats `{ audio, ebook, read_along }`, chapters `[{ index, title, start, end }]`, progress `{ position, updated_at }`, bookmarks, `cover_tint` (hex, the colour already computed for the web player) |
| `GET /api/books/{id}/cover?size=560` | JPEG at the asked size. Use 280 for rows, 248 for the grid, 560 for Now playing, and 1200 for backdrops. |
| `GET /api/books/{id}/audio` | The audio, with HTTP range requests. Serve AAC/M4B or MP3 as stored; both platforms play them. |
| `PUT /api/progress` `{ book_id, position, updated_at }` | Every 10 s while playing and on pause. The newest `updated_at` wins, the same rule as the web app. |
| `POST /api/books/{id}/bookmarks` `{ position }` | Hold OK (LG) or long-press the clickpad (Apple TV) on Now playing. |
| `GET /api/books/{id}/read-along/{chapter}` | `{ sentences: [{ start, end, text, words: [{ start, end }] }] }`, from the alignment the web reader already uses. |
| `GET /api/search?q=` | `{ books: [BookCard], series: [...], people: [...] }` |
| `POST /api/tv/{device}/keyboard` (phone) / `GET /api/tv/keyboard` (TV, long poll) | Phone typing for search. The phone shows a text field while the TV's search is open. |

`BookCard` = `{ id, title, author, cover_url, progress: 0..1 | null, read_along: bool }`.

## 4. Focus: the whole interface

- **Exactly one thing is focused, and it's the brightest thing on screen.**
  - A focused button fills cream (`tv-focus`) with dark text (`tv-on-focus`) and scales to 108%.
  - A focused book scales to 110%, lifts with a deep shadow, and gets a 4 px cream ring and a soft shine.
  - Keys scale to 112%.
  - Resting controls are glass (`tv-glass`) over a darkened backdrop.
- **Speed:** focus moves in 180 ms (`duration-tv-focus`); backdrops cross-fade in 600 ms (`duration-tv-backdrop`), after focus has rested 300 ms.
- **Never lose focus off screen.** Rows scroll so the focused card stays inside the safe area, and the first card never moves off the left margin.
- **Memory:** each row and grid remembers its last focused item, so going down and back up returns to the same book. Leaving a screen and pressing Back restores focus where it was.

| Screen | Starts on | ▲ | ▼ | Back |
| --- | --- | --- | --- | --- |
| Sign in | Nothing to focus; it waits | | | Exits the app |
| Profiles | The last person who used this TV | | | Exits the app |
| Home | Resume (or the first card if nothing is in progress) | Hero → top nav | Hero → row, remembered item | Top nav: goes to Home; on Home, exits the app |
| Library | Last focused book, else the first | Grid → filters → nav | Filters → grid | Home |
| Book | Resume / Start listening | Buttons → nav | Buttons → chapter tiles | Where you came from |
| Search | The letter "a" | Results → nav | | Clears the query, then Home |
| Now playing | Play/pause | Opens Chapters | Opens Read along | Back to the screen you came from; audio keeps playing |
| Chapters / Sleep panel | Next chapter / End of chapter | Up the list | Down the list | Closes the panel |
| Read along | Nothing focused; ◀ ▶ move by sentence, OK pauses | Back to Now playing | | Now playing |

## 5. Remotes

| Action | Apple TV (Siri Remote) | LG (Magic Remote) |
| --- | --- | --- |
| Move focus | Swipe or press the clickpad ring | Arrow keys; pointing at something also focuses it |
| Choose | Click | OK |
| Back | Back (Menu on older remotes) | Back |
| Play / pause | ⏯ | ⏯ (or Play and Pause) |
| Back 15 s / forward 30 s | Click left / right on the ring in Now playing; hold to scrub | ⏪ / ⏩ |
| Bookmark | Long-press the clickpad in Now playing | Hold OK in Now playing |

- **Apple TV:** use SwiftUI focus (`.focusable`, `@FocusState`, `.focusSection()` for rows) and `.buttonStyle(.card)` on covers for the system lift, shine and tilt. `apple-reference/FocusStyles.swift` shows the cream button style and the book card.
- **Web TV (LG):** the browser doesn't move focus between items with arrows, so the app does. `web-prototype/spatial-nav.js` is a small dependency-free reference: nearest item in the pressed direction, focus memory per group, the `.is-focus` class, and the pointer focusing on hover.
  - The keycodes it handles are arrows 37–40, OK 13, and Back 461 on webOS.
  - For production, a maintained library such as `@noriginmedia/norigin-spatial-navigation` is a good alternative.
  - Check the media keys (Play, Pause, Rewind, Fast-forward) against LG's webOS key code table on a real TV, because remotes differ by year.

## 6. Playback

- **One player per app,** owned above the screens, so navigating never stops audio.
- **Apple TV:**
  - Use `AVPlayer` with the audio session set to `.playback` and the "audio" background mode, so playback continues after pressing the TV button.
  - Fill `MPNowPlayingInfoCenter` (title, author, chapter, artwork, elapsed time).
  - Handle `MPRemoteCommandCenter` skip back 15 / forward 30 and play/pause.
  - See `apple-reference/NowPlayingIntegration.swift`.
- **LG:**
  - Use an HTML `<audio>` element.
  - Test on a real TV whether audio continues when the person leaves the app. If it doesn't, pause and save progress on `visibilitychange`, and show nothing alarming; the place is saved.
- **Progress:** `PUT /api/progress` every 10 s and on pause, as in section 3. On start, take whichever of server and local is newer.
- **Sleep timer:** fades the volume to zero over the last 10 s, then pauses.

## 7. Visual rules

- **Tokens:**
  - `design/tokens.json` and `design/tokens.css` (the TV ones start with `tv-`, plus `duration-tv-*`).
  - `design/bundle.css` has the `ts-tv-*` classes used by the screens.
  - `apple-reference/Theme.swift` has the same values for SwiftUI.
  - Generate Swift and CSS from `shared/tokens.json` so they can't drift.
- **Type:**

  | Style | Size |
  | --- | --- |
  | Display | Fraunces 84 |
  | Titles | Fraunces 56 |
  | Row headings | Fraunces 36 |
  | Body | Fira Sans 30 |
  | Buttons | Fira Sans 28 semibold |
  | Read-along sentence | Fraunces 60 |

  **Nothing is smaller than 24 px.** Bundle the fonts with both apps; TVs have no reliable font fallback.
- **Safe area:** text and controls stay 96 px from the sides and 54 px from the top and bottom. Rows of covers may run past the right edge to show there's more.
- **Backdrops:**
  - The focused or current book's cover, large, faded in from the left.
  - Its `cover_tint` as a soft glow.
  - A walnut-black scrim from the left and bottom, so text reads at 7:1.
  - Covers come from the server at 1200 px; never upscale a small one, use the tint alone instead.
- **The ember accent** marks progress and the "Continue listening" overline. On Now playing, progress uses the book's cover accent, as on the web player.
- **Copy:** the same voice as the web app. Sentence case, no exclamation marks, specific times ("18 min left in chapter").
- **Screen snapshots:** `screens/*.html` are reference markup for the web build, using these classes. They're snapshots, not production code.

## 8. Accessibility

- **Labels:**
  - VoiceOver (Apple TV) and LG's Audio Guidance read every focusable item.
  - Give covers "Title, by Author", plus "has read along" and progress ("62% listened") where they apply.
  - Give icon-only buttons their action ("Back 15 seconds").
- **Reduce Motion** (Apple TV setting, or `prefers-reduced-motion` on web): no scaling, the focus ring and fill only, and backdrops change without the cross-fade.
- **Large text** (Rosa's profile): body text goes from 30 to 36 px, and covers in rows from 280 to 320 px.
- **Ambient mode** never hides anything that's needed: any button brings the controls back, and the clock and progress stay.

## 9. Done when

- [ ] A TV signs in by code or QR in under a minute without typing on the remote, and stays signed in.
- [ ] Every screen in section 2 matches its picture at 1920 × 1080 on a real Apple TV and a real LG TV.
- [ ] On every screen, focus starts where the table says, never disappears, never lands off screen, and Back does what the table says.
- [ ] Rows remember their position; up from the Home row returns to the hero's buttons.
- [ ] Play, pause and skip work from the remote's media keys anywhere in the app.
- [ ] On Apple TV, audio keeps playing on the system's Now Playing screen after you leave the app.
- [ ] Progress saved on the TV shows on the phone and web within 10 s, and the other way round.
- [ ] Read along highlights the right sentence and word, using the server's alignment.
- [ ] VoiceOver and Audio Guidance read every focusable item; Reduce Motion removes the scaling.
- [ ] No text under 24 px and nothing outside the safe area.

## Files in this package

| Path | What it is |
| --- | --- |
| `screens/01–13 *.png` | Every screen. The `.html` beside each is a reference snapshot for the web build. |
| `design/` | Tokens (JSON and CSS), `bundle.css` with the `ts-tv-*` classes, logos. |
| `web-prototype/` | Home with working arrow-key focus, focus memory, backdrop-follows-focus and the pointer (`index.html`, `spatial-nav.js`). |
| `apple-reference/` | `Theme.swift`, `FocusStyles.swift`, `NowPlayingIntegration.swift`. Reference SwiftUI for tvOS 17+, written for this handoff and not compiled here. |
