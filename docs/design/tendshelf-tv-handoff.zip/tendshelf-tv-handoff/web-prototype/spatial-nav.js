/*
 * Tendshelf TV spatial navigation: a small reference for the web TV app (LG webOS, later Samsung and Android TV).
 * No dependencies. Moves focus with the arrow keys (and webOS remote codes), remembers the last focused item per group,
 * marks focus with .is-focus (the design system's TV focus style), and lets a pointer (LG Magic Remote) focus by hovering.
 *
 *   TendshelfSpatialNav.mount(root, { start: element })
 *   Focusable elements: [data-focus], grouped by data-group ("nav", "hero", "row", …).
 *   Events: "tv-focus" (detail.element) whenever focus moves; "tv-select" on OK; "tv-back" on Back.
 */
(function (global) {
  'use strict';
  var KEY = { 37: 'left', 38: 'up', 39: 'right', 40: 'down', 13: 'ok', 461: 'back', 8: 'back', 27: 'back' };

  function mount(root, opts) {
    var current = null, memory = {};

    function items() { return Array.prototype.slice.call(root.querySelectorAll('[data-focus]')).filter(function (el) { return el.offsetParent !== null || el.getClientRects().length; }); }
    function rect(el) { return el.getBoundingClientRect(); }

    function focus(el, silent) {
      if (!el || el === current) return;
      if (current) current.classList.remove('is-focus');
      current = el;
      el.classList.add('is-focus');
      el.focus({ preventScroll: true });
      if (el.dataset.group) memory[el.dataset.group] = el;
      keepInView(el);
      if (!silent) root.dispatchEvent(new CustomEvent('tv-focus', { detail: { element: el } }));
    }

    // Rows scroll horizontally so the focused card is never cut off; the first card keeps its place at the safe margin.
    function keepInView(el) {
      var row = el.closest('.ts-tv-row');
      if (!row) return;
      var r = rect(el), safe = 96 * scale(), right = window.innerWidth - safe;
      var shift = Number(row.dataset.shift || 0);
      if (r.right > right) shift -= (r.right - right) / scale();
      if (r.left < safe) shift += (safe - r.left) / scale();
      shift = Math.min(0, shift);
      row.dataset.shift = String(shift);
      row.style.transition = 'transform var(--duration-tv-focus) var(--easing-standard)';
      row.style.transform = 'translateX(' + shift + 'px)';
    }
    function scale() { var m = /scale\(([\d.]+)\)/.exec(root.style.transform || ''); return m ? Number(m[1]) : 1; }

    // Find the nearest item in a direction. Entering another group goes to the item remembered for it.
    function move(dir) {
      if (!current) { focus(items()[0]); return; }
      var a = rect(current), ax = a.left + a.width / 2, ay = a.top + a.height / 2, best = null, bestScore = Infinity;
      items().forEach(function (el) {
        if (el === current) return;
        var b = rect(el), bx = b.left + b.width / 2, by = b.top + b.height / 2, dx = bx - ax, dy = by - ay;
        var along = dir === 'left' ? -dx : dir === 'right' ? dx : dir === 'up' ? -dy : dy;
        var across = dir === 'left' || dir === 'right' ? Math.abs(dy) : Math.abs(dx);
        if (along <= 1) return;
        var score = along + across * 2.5;
        if (score < bestScore) { bestScore = score; best = el; }
      });
      if (!best) return;
      var g = best.dataset.group;
      if (g && g !== current.dataset.group && memory[g] && memory[g].isConnected && (dir === 'up' || dir === 'down')) best = memory[g];
      focus(best);
    }

    document.addEventListener('keydown', function (e) {
      var k = KEY[e.keyCode];
      if (!k) return;
      e.preventDefault();
      if (k === 'ok') { if (current) { current.dispatchEvent(new CustomEvent('tv-select', { bubbles: true })); current.click(); } return; }
      if (k === 'back') { root.dispatchEvent(new CustomEvent('tv-back')); return; }
      move(k);
    });

    // LG Magic Remote: the pointer focuses what it's over; arrows take over again when it hides.
    root.addEventListener('mousemove', function (e) { var el = e.target.closest && e.target.closest('[data-focus]'); if (el) focus(el); });
    document.addEventListener('cursorStateChange', function () { /* webOS: pointer shown or hidden; focus stays where it is */ });

    focus(opts && opts.start || items()[0]);
    return { focus: focus, current: function () { return current; }, refresh: function () { if (current && !root.contains(current)) focus(items()[0]); } };
  }

  global.TendshelfSpatialNav = { mount: mount };
})(window);
