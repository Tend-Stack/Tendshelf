# Instructions

This repo is the Tendshelf TV app. Follow `HANDOFF.md`. Build the Apple TV app in `apple/` and the web TV app (LG first) in `web/`, as section 1 lays out, and add the server endpoints in section 3 to the main Tendshelf repo. The pictures in `screens/` are the target; `design/` holds the tokens and classes.
