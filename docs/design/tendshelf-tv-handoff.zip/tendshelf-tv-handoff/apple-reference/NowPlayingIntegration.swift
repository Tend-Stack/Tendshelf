// Playback on tvOS: background audio, the Now Playing screen and the Siri Remote.
// Reference code for tvOS 17+, not compiled in this handoff. Add "audio" to UIBackgroundModes.
import AVFoundation
import MediaPlayer

final class Player {
    let av = AVPlayer()
    private var timeObserver: Any?
    var onProgress: ((Double) -> Void)?       // send to PUT /api/progress every 10 s and on pause

    func start(url: URL, at seconds: Double, title: String, author: String, chapter: String, artwork: UIImage?) throws {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
        try AVAudioSession.sharedInstance().setActive(true)
        av.replaceCurrentItem(with: AVPlayerItem(url: url))
        av.seek(to: CMTime(seconds: seconds, preferredTimescale: 600))
        av.play()

        var info: [String: Any] = [
            MPMediaItemPropertyTitle: title,
            MPMediaItemPropertyArtist: author,
            MPMediaItemPropertyAlbumTitle: chapter,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: seconds,
            MPNowPlayingInfoPropertyPlaybackRate: 1.0,
        ]
        if let artwork {
            info[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: artwork.size) { _ in artwork }
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info

        let center = MPRemoteCommandCenter.shared()
        center.skipBackwardCommand.preferredIntervals = [15]
        center.skipForwardCommand.preferredIntervals = [30]
        center.skipBackwardCommand.addTarget { [weak self] _ in self?.skip(-15); return .success }
        center.skipForwardCommand.addTarget { [weak self] _ in self?.skip(30); return .success }
        center.togglePlayPauseCommand.addTarget { [weak self] _ in
            guard let self else { return .commandFailed }
            self.av.timeControlStatus == .playing ? self.av.pause() : self.av.play()
            return .success
        }

        timeObserver = av.addPeriodicTimeObserver(forInterval: CMTime(seconds: 10, preferredTimescale: 1), queue: .main) { [weak self] t in
            self?.onProgress?(t.seconds)
        }
    }

    func skip(_ by: Double) {
        let t = av.currentTime().seconds + by
        av.seek(to: CMTime(seconds: max(0, t), preferredTimescale: 600))
    }
}
