// Focus treatments from the TV design. Reference code for tvOS 17+, not compiled in this handoff.
import SwiftUI

/// Text-and-icon buttons (Resume, Read along, Chapters, Sleep): glass at rest, cream fill when focused.
struct TVButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        TVButtonBody(configuration: configuration)
    }

    private struct TVButtonBody: View {
        let configuration: ButtonStyle.Configuration
        @Environment(\.isFocused) private var isFocused
        @Environment(\.accessibilityReduceMotion) private var reduceMotion

        var body: some View {
            configuration.label
                .font(TS.label())
                .padding(.horizontal, 40)
                .frame(height: 80)
                .foregroundStyle(isFocused ? TS.onFocus : TS.ink)
                .background(Capsule().fill(isFocused ? TS.focus : TS.glass))
                .scaleEffect(reduceMotion ? 1 : (isFocused ? 1.08 : 1))
                .shadow(color: .black.opacity(isFocused ? 0.6 : 0), radius: 20, y: 18)
                .animation(TS.focusAnimation, value: isFocused)
        }
    }
}

/// Book covers in rows and grids. `.buttonStyle(.card)` gives the system lift, shine and Siri Remote tilt;
/// the title under the cover brightens when its card is focused.
struct BookCard: View {
    let title: String
    let cover: Image
    var progress: Double? = nil      // 0…1, shows the ember bar
    var hasReadAlong = false
    var size: CGFloat = TS.card
    let action: () -> Void
    @FocusState private var focused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Button(action: action) {
                ZStack(alignment: .bottom) {
                    cover.resizable().aspectRatio(1, contentMode: .fill)
                        .frame(width: size, height: size)
                    if let progress {
                        GeometryReader { g in
                            Capsule().fill(TS.ground.opacity(0.6))
                                .overlay(alignment: .leading) { Capsule().fill(TS.accent).frame(width: g.size.width * progress) }
                        }
                        .frame(height: 6).padding(14)
                    }
                }
                .overlay(alignment: .topTrailing) {
                    if hasReadAlong {
                        Image(systemName: "text.bubble").padding(10).background(Circle().fill(TS.ground.opacity(0.8))).padding(12)
                    }
                }
            }
            .buttonStyle(.card)
            .focused($focused)
            .accessibilityLabel(Text(title + (hasReadAlong ? ", has read along" : "")))

            Text(title)
                .font(TS.meta())
                .fontWeight(focused ? .semibold : .medium)
                .foregroundStyle(focused ? TS.ink : TS.inkMuted)
                .lineLimit(1)
                .frame(width: size, alignment: .leading)
        }
    }
}
