// Tendshelf TV theme for tvOS (SwiftUI). Values come from design/tokens.json.
// Reference code: written for tvOS 17+, not compiled in this handoff. Bundle Fraunces and Fira Sans in the app
// (Info.plist UIAppFonts) or swap in the system serif/sans until they're added.
import SwiftUI

extension Color {
    init(hex: UInt32, alpha: Double = 1) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: alpha)
    }
}

enum TS {
    // Colour (TV is always dark)
    static let ground = Color(hex: 0x14110E)
    static let surface = Color(hex: 0x1E1A15)
    static let ink = Color(hex: 0xF1E8DA)
    static let inkMuted = Color(hex: 0xB5A894)
    static let accent = Color(hex: 0xE2703A)          // ember: progress, "Continue listening" overline
    static let success = Color(hex: 0x7CC4B8)
    static let glass = Color(hex: 0xF1E8DA, alpha: 0.12)        // tv-glass: resting buttons, nav, keys
    static let glassStrong = Color(hex: 0xF1E8DA, alpha: 0.20)  // tv-glass-strong: current nav item
    static let focus = Color(hex: 0xF1E8DA)            // tv-focus: focused button fill, card ring
    static let onFocus = Color(hex: 0x14110E)          // tv-on-focus

    // Type (tvOS points equal the 1920×1080 design's pixels)
    static func display() -> Font { .custom("Fraunces", size: 84).weight(.medium) }
    static func title() -> Font { .custom("Fraunces", size: 56).weight(.medium) }
    static func heading() -> Font { .custom("Fraunces", size: 36).weight(.medium) }
    static func body() -> Font { .custom("FiraSans-Regular", size: 30) }
    static func label() -> Font { .custom("FiraSans-SemiBold", size: 28) }
    static func meta() -> Font { .custom("FiraSans-Medium", size: 24) }       // nothing smaller than this
    static func read() -> Font { .custom("Fraunces", size: 60) }              // read-along sentence

    // Space and motion
    static let safeX: CGFloat = 96      // tvOS already insets content; use these only for full-bleed screens
    static let safeY: CGFloat = 54
    static let card: CGFloat = 280      // cover size in rows; 248 in the library grid
    static let focusAnimation = Animation.timingCurve(0.2, 0, 0, 1, duration: 0.18)
    static let backdropAnimation = Animation.timingCurve(0.2, 0, 0, 1, duration: 0.6)
}
