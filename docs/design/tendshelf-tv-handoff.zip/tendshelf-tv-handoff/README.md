# Tendshelf TV

A separate project: the living-room app for Tendshelf, for Apple TV and LG first. Start with `HANDOFF.md`, then look at `screens/` in order and try `web-prototype/index.html` with the arrow keys.
